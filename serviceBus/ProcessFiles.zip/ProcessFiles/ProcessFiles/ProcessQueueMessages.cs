using System;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Azure.Messaging.ServiceBus;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using ProcessFiles.Models;
using Container = Microsoft.Azure.Cosmos.Container;

namespace ProcessFiles
{
    public class ProcessQueueMessages
    {
        private static string blob_connection_string = "DefaultEndpointsProtocol=https;AccountName=appstore443443;AccountKey=b4r4Y5SrQQhj8FEQXlpqCjmZe6vSyedcryw7vLVYuaqW/H/FjXUwED3d0fJVOfWkRfDcTS2QDg4q+AStaFK1XA==;EndpointSuffix=core.windows.net";
        private static string source_container_name = "unprocessed";
        private static string destination_container_name = "processed";

        private static readonly string _connection_string = "AccountEndpoint=https://appaccount28787373.documents.azure.com:443/;AccountKey=cLVREQYGBMys1tbPAUwzYIOHA7mbcoVjmS2JHWuwcDUjL92Fs77Gxx1PF67JSi4vV0X53H5TNjjPACDbPB4c1g==;";
        private static readonly string _database_name = "logdb";
        private static readonly string _container_name = "bloblogs";

        [FunctionName("ProcessMessages")]
        public static async Task Run([ServiceBusTrigger("filequeue", Connection = "queueconnection")] ServiceBusReceivedMessage myQueueItem, ILogger log)
        {
            Item _message = JsonSerializer.Deserialize<Item>(Encoding.UTF8.GetString(myQueueItem.Body));

            BlobServiceClient _client = new BlobServiceClient(blob_connection_string);
            BlobContainerClient _source_container_client = _client.GetBlobContainerClient(source_container_name);
            BlobClient _source_blob_client = _source_container_client.GetBlobClient(_message.ItemName);

            BlobContainerClient _destination_container_client = _client.GetBlobContainerClient(destination_container_name);
            BlobClient _destination_blob_client = _destination_container_client.GetBlobClient(_message.ItemName);

            CosmosClient _cosmosclient = new CosmosClient(_connection_string, new CosmosClientOptions());
            Container _container = _cosmosclient.GetContainer(_database_name, _container_name);

            BlobDownloadInfo _info = _source_blob_client.Download();
            // Copy the blob to the destination container
            await _destination_blob_client.StartCopyFromUriAsync(_source_blob_client.Uri);

            log.LogInformation(_info.Details.LastModified.ToString());
            log.LogInformation(_info.ContentLength.ToString());

            BlobDetails _blobdetails = new BlobDetails();
            _blobdetails.BlobName = _message.ItemName;
            _blobdetails.BlobLocation = "https://appstore443443.blob.core.windows.net/processed/" + _message.ItemName;
            _blobdetails.ContentLength = _info.ContentLength.ToString();
            _blobdetails.LastModified = _info.Details.LastModified.ToString();
            _blobdetails.id = Guid.NewGuid().ToString();

            _container.CreateItemAsync(_blobdetails, new PartitionKey(_message.ItemName)).GetAwaiter().GetResult();
            Console.WriteLine("Item created");

            // Delete the blob from the unprocessed container
            _source_blob_client.Delete();
            // Add the details of the blob to an Azure Cosmos DB account

        }
    }
}
