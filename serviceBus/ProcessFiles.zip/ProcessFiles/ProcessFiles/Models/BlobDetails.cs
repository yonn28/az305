﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProcessFiles.Models
{
    class BlobDetails
    {
        public string id { get; set; }
        public string LastModified { get; set; }
        public string ContentLength { get; set; }
        public string BlobName { get; set; }
        public string BlobLocation { get; set; }
    }
}
