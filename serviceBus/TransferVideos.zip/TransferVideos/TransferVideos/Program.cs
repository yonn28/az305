﻿using Azure.Messaging.ServiceBus;
using Azure.Storage.Blobs;
using System.IO;
using TransferVideos;

string blob_connection_string = "DefaultEndpointsProtocol=https;AccountName=appstore443443;AccountKey=b4r4Y5SrQQhj8FEQXlpqCjmZe6vSyedcryw7vLVYuaqW/H/FjXUwED3d0fJVOfWkRfDcTS2QDg4q+AStaFK1XA==;EndpointSuffix=core.windows.net";
string servicebus_connection_string = "Endpoint=sb://busnamespace34434.servicebus.windows.net/;SharedAccessKeyName=SendPolicy;SharedAccessKey=IY8mtLPTiYI7wa7O77KN+QTSxgTywhhRn+ASbKzby8s=;EntityPath=filequeue";

string container_name = "unprocessed";
string strPath = "C:\\tmp3";
string queue_name = "filequeue";

BlobServiceClient _client = new BlobServiceClient(blob_connection_string);
BlobContainerClient _container_client = _client.GetBlobContainerClient(container_name);

ServiceBusClient _busclient = new ServiceBusClient(servicebus_connection_string);
ServiceBusSender _sender = _busclient.CreateSender(queue_name);


string[] filenames = Directory.GetFiles(strPath);

foreach (string filename in filenames)
{
 
    BlobClient _blob_client = _container_client.GetBlobClient(Path.GetFileName(filename));
    await _blob_client.UploadAsync(filename);

    Item item = new Item();
    item.ItemName = Path.GetFileName(filename);
    item.ItemLocation = "https://appstore443443.blob.core.windows.net/unprocessed/" + Path.GetFileName(filename);

    ServiceBusMessage _message = new ServiceBusMessage(item.ToString());
    _message.ContentType = "application/json";
    await _sender.SendMessageAsync(_message);

    Console.WriteLine($"Uploaded blob {filename}");
}


